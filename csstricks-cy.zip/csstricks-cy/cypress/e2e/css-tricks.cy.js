// This tests each menu item in the nav bar

describe('CSS Tricks Homepage Menu Items', () => {
  beforeEach(() => {
    cy.visit('https://css-tricks.com/');
  });
  
  it('clicks articles button', () => {
    cy.get('.articles').click();
  });

  it('clicks videos button', () => {
    cy.get('.videos').click();
  });

  it('clicks almanac button', () => {
    cy.get('.almanac').click();
  });

  it('clicks newsletter button', () => {
    cy.get('.newsletter').click();
  });

  it('clicks guides button', () => {
    cy.get('.guides').click();
  });

  it('clicks digitalocean button', () => {
    cy.get('.do').click();
  });

  it('clicks do community button', () => {
    cy.get('.doc').click();
  });
 
});